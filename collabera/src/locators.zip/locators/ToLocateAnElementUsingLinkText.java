package locators;

public class ToLocateAnElementUsingLinkText {

}
